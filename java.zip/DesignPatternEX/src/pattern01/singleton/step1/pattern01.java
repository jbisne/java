package pattern01.singleton.step1;

public class pattern01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
