
public class E1_SBox implements java.io.Serializable {
	String s;

	public E1_SBox(String s) {
		this.s = s;
	}
	
	public String get() {
		return s;

	}

}
