package chapter06;
import java.util.Scanner;

public class Quiz0603 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("점수를 입력하세요.");
		
		System.out.println("국어 점수 : ");
		int num1 = sc.nextInt();
		
		int avg = 
		
		if (avg > 90)
			sResult = "A"; //""쓰면 변수명이 String
		else if (avg > 80)
			sResult = "B";
		else if (avg > 80)
			sResult = "C";
		else if (avg > 80)
			sResult = "D";
		else ()
	}

}