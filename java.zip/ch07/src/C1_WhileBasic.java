public class C1_WhileBasic {

	public static void main(String[] args) {
		int num = 0;
		
		while(num < 5) {
			System.out.println("I like Java" + num);
			num++;
		}
	}
}
