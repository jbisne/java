public class AAA {
	public void showName()	{
		System.out.println("My name is AAA");
	}
}	
