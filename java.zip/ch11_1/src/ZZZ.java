public class ZZZ {
	public void showName() {
		System.out.println("My name is ZZZ");
	}
}
