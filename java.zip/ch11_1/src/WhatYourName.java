class WhatYourName {
	public static void main(String[] args) {
		AAA aaa = new AAA();
		aaa.showName();
	
		ZZZ zzz = new ZZZ();
		zzz.showName();
			
	}
}
