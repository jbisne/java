
public class A_Arith0p {

	public static void main(String[] args) {
		int num1 = 7;
		int num2 = 3;
		
		System.out.println("num1 + num2 = " +(num1 + num2));
		System.out.println("num1 - num2 = " +(num1 - num2));
		System.out.println("num1 * num2 = " +(num1 * num2));
		System.out.println("num1 / num2 = " +(num1 / num2));
		System.out.println("num1 % num2 = " +(num1 % num2));
	}

}
