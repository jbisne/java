
public class C_Relational0p {

	public static void main(String[] args) {
		System.out.println("3 >= 2 : " + (3 >= 2));
		System.out.println("3 <= 2 : " + (3 <= 2));
		
		//비교 연산시 형 변환이 일어난다.
		System.out.println("7.0 == 7 : " + (7.0 == 7));
		System.out.println("7.0 != 7 : " + (7.0 != 7));


	}

}
