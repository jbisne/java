package step1;

public class Main {

	public static Person createPersonForTesting() {
		Person person = new Person();
		person.setFirstName("FirstName");
		person.setLastName("LastName");
		person.setAddressOne("Address1");
		//...
		return person;

	}

}
