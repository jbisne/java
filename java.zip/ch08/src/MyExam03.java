public class MyExam03 {

	public static void main(String[] args) {
		// 메서드마다 다르다. 밖에있는 변수는 안쪽에 들어갈수잇지만
		// 안쪽에 있는 변수는 밖으로 빠져나올수없다.
		int num1 = 1;
		int num2 = 2;
		Add1(num1, num2);
		Add2(num1, num2);
		
		for (int i=0; i < 10; i++ ) {
			System.out.println(i);
			int numX = 0;
		}
		System.out.println(num1); //출력했을때 요기가 맨아래 1 부분.
	}
	
	public static void Add1(int num3, int num4) {
		int num1 = num3;
		int num2 = num4;
		
		System.out.println(num1 + num2);
	}
	
	public static void Add2(int num1, int num2) {
		System.out.println(num1 + num2);
	}
}
