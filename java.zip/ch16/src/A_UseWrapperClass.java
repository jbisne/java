public class A_UseWrapperClass {

	public static void main(String[] args) {
		String a = "34";
		int b = 50;
		int c = Integer.parseInt(a);
		int d = c + b;
		
		System.out.println(a+"+"+b+"+"+c);

	}

}
