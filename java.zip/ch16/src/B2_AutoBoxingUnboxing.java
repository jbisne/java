public class B2_AutoBoxingUnboxing {
	public static void main(String[] args) {
		Integer i0bj = 10;
		Double d0bj = 3.14;
		
		System.out.println(i0bj);
		System.out.println(d0bj);
		System.out.println();
		
		int num1 = i0bj;
		double num2 =d0bj;
		
		System.out.println(num1);
		System.out.println(num2);
	}

}
