//
// Number 클ㄹ래스의 추상 메서드 호출의 예
//

class C1_NumberMethod {
	public static void main(String[] args) {
		Integer num1= new Integer (29);
		System.out.println(num1.intValue());
		System.out.println(num1.doubleValue());
		
		Double num2 = new Double(3.14);
		System.out.println(num2.intValue());
		System.out.println(num2.doubleValue());
		

	}

}
