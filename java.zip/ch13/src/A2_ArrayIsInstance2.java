//A1하고 같은 의미다
class BoxA2 {

}

class A2_ArrayIsInstance2 {
	public static void main(String[] args) {
		BoxA2[] ar = new BoxA2[5];
		// =클래스 5개가 만들어졋다고 보면됨.
		System.out.println("length : " + ar.length);
		// = 객체도 배열로 만들수잇다. 라는 예제.
		

	}

}
